"use client"

import { useFetchData } from "./hooks/useFetchData"
import VideoCard from "./components/videocard"
import VerseCard from "./components/versecard"
import EventImage from "./components/eventimage"
import type { Video, Verse, Event } from "./types"
import { Button } from "./components/ui/button"
import { Card, CardContent } from "./components/ui/card"
import { Navbar } from "./components/navbar"
import { Footer } from "./components/footer"

export default function MinisterioPage() {
  const { videos, verses, events } = useFetchData()

  // Default content (as before)
  const defaultVideos: Video[] = [
    { url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" },
    { url: "https://www.youtube.com/watch?v=JGwWNGJdvx8" },
  ]

  const defaultVerses: Verse[] = [
    {
      text: "Porque de tal manera amó Dios al mundo, que ha dado a su Hijo unigénito, para que todo aquel que en él cree no se pierda, mas tenga vida eterna.",
      reference: "Juan 3:16",
    },
    { text: "El Señor es mi pastor, nada me faltará.", reference: "Salmos 23:1" },
  ]

  const defaultEvents: Event[] = [
    { id: "event1", imageUrl: "/fondis2.jpg", title: "Retiro Espiritual", date: "15 de Agosto, 2023" },
    { id: "event2", imageUrl: "/fondis3.jpg", title: "Concierto de Alabanza", date: "22 de Septiembre, 2023" },
  ]

  const displayedVideos = videos.length > 0 ? videos : defaultVideos
  const displayedVerses = verses.length > 0 ? verses : defaultVerses
  const displayedEvents = events.length > 0 ? events : defaultEvents

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative h-[60vh] flex items-center justify-center text-white">
          <div className="absolute inset-0 bg-black opacity-50 z-10"></div>
          <div
            className="absolute inset-0 bg-cover bg-center z-0"
            style={{ backgroundImage: "url('/hero-background.jpg')" }}
          ></div>
          <div className="relative z-20 text-center">
            <h1 className="text-5xl font-bold mb-4">Ministerio Fodins</h1>
            <p className="text-xl mb-8">Compartiendo la palabra de Dios con el mundo</p>
            <Button size="lg">Conócenos</Button>
          </div>
        </section>

        {/* Mission Section */}
        <section className="py-16 bg-gray-100">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-8">Nuestra Misión</h2>
            <p className="text-xl text-center max-w-3xl mx-auto">
              En Ministerio Fodins, nos dedicamos a difundir el amor y la palabra de Dios, inspirando a las personas a
              vivir una vida plena y significativa a través de la fe y el servicio a los demás.
            </p>
          </div>
        </section>

        {/* Videos Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Videos Inspiradores</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {displayedVideos.map((video, index) => (
                <VideoCard key={index} url={video.url} />
              ))}
            </div>
          </div>
        </section>

        {/* Versículos Section */}
        <section className="py-16 bg-gray-100">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Versículos del Día</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {displayedVerses.map((verse, index) => (
                <VerseCard key={index} text={verse.text} reference={verse.reference} />
              ))}
            </div>
          </div>
        </section>

        {/* Eventos Section */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Próximos Eventos</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {displayedEvents.map((event) => (
                <Card key={event.id}>
                  <CardContent className="p-0">
                    <EventImage src={event.imageUrl} />
                    <div className="p-4">
                      <h3 className="text-xl font-semibold mb-2">{event.title}</h3>
                      <p className="text-gray-600">{event.date}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Call to Action Section */}
        <section className="py-16 bg-blue-600 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">Únete a Nuestra Comunidad</h2>
            <p className="text-xl mb-8">Descubre cómo puedes ser parte de nuestra misión y crecer en tu fe.</p>
            <Button variant="secondary" size="lg">
              Contáctanos
            </Button>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

