"use client";

import { useState } from "react";
import { db, storage } from "../firebase/firebase";
import { collection, addDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { Button } from "../components/ui/button";

export default function UploadForm() {
  const [videoUrl, setVideoUrl] = useState("");
  const [verseText, setVerseText] = useState("");
  const [verseReference, setVerseReference] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleUpload = async () => {
    setLoading(true);
    setError(null);
    setSuccess(null);

    // Input validation
    if (!videoUrl && (!verseText || !verseReference) && !image) {
      setError("Por favor, proporciona al menos un video, un versículo o una imagen.");
      setLoading(false);
      return;
    }

    try {
      if (videoUrl) {
        await addDoc(collection(db, "videos"), { url: videoUrl });
      }

      if (verseText && verseReference) {
        await addDoc(collection(db, "verses"), { text: verseText, reference: verseReference });
      }

      if (image) {
        const storageRef = ref(storage, `events/${Date.now()}_${image.name}`);
        await uploadBytes(storageRef, image);
        const imageUrl = await getDownloadURL(storageRef);
        await addDoc(collection(db, "events"), { imageUrl });
      }

      setSuccess("Contenido subido exitosamente!");
      setVideoUrl("");
      setVerseText("");
      setVerseReference("");
      setImage(null);
    } catch (error) {
      console.error("Error subiendo contenido: ", error);
      setError("Hubo un error al subir el contenido. Por favor, intente de nuevo.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 bg-white shadow-md rounded-md">
      <h2 className="text-2xl font-semibold mb-4">Subir contenido</h2>

      {error && <div className="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">{error}</div>}

      {success && <div className="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded">{success}</div>}

      <div className="space-y-4">
        <input
          type="text"
          placeholder="URL del video (YouTube)"
          value={videoUrl}
          onChange={(e) => setVideoUrl(e.target.value)}
          className="w-full p-2 border border-gray-300 rounded"
        />

        <input
          type="text"
          placeholder="Texto del versículo"
          value={verseText}
          onChange={(e) => setVerseText(e.target.value)}
          className="w-full p-2 border border-gray-300 rounded"
        />
        <input
          type="text"
          placeholder="Referencia del versículo"
          value={verseReference}
          onChange={(e) => setVerseReference(e.target.value)}
          className="w-full p-2 border border-gray-300 rounded"
        />

        <input
          type="file"
          onChange={(e) => setImage(e.target.files?.[0] || null)}
          className="w-full p-2 border border-gray-300 rounded"
        />

        <Button onClick={handleUpload} disabled={loading} className="w-full">
          {loading ? "Subiendo..." : "Subir contenido"}
        </Button>
      </div>
    </div>
  );
}
