// components/Footer.tsx
export function Footer() {
  return <footer className="bg-gray-900 text-white text-center p-4">Ministerio © 2025</footer>;
}