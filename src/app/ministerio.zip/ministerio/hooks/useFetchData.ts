import { useEffect, useState } from "react";
import { collection, getDocs } from "firebase/firestore";
import { db } from "../firebase/firebase";
import { Video, Verse, Event } from "../types";

export const useFetchData = () => {
  const [videos, setVideos] = useState<Video[]>([]);
  const [verses, setVerses] = useState<Verse[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const videosSnapshot = await getDocs(collection(db, "videos"));
        const versesSnapshot = await getDocs(collection(db, "verses"));
        const eventsSnapshot = await getDocs(collection(db, "events"));

        setVideos(videosSnapshot.docs.map((doc) => doc.data() as Video));
        setVerses(versesSnapshot.docs.map((doc) => doc.data() as Verse));
        setEvents(eventsSnapshot.docs.map((doc) => doc.data() as Event));
      } catch (err) {
        console.error("Error fetching data: ", err);
        setError("Error fetching data. Please try again later.");
      }
    };

    fetchData();
  }, []);

  return { videos, verses, events, error };
};
